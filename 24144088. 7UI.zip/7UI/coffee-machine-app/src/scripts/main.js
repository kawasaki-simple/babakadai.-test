const coffeeTypes = {
    espresso: {
        name: "Espresso",
        price: 2.5,
    },
    latte: {
        name: "Latte",
        price: 3.0,
    },
    cappuccino: {
        name: "Cappuccino",
        price: 3.5,
    },
};

document.addEventListener("DOMContentLoaded", () => {
    const coffeeSelect = document.getElementById("coffee-select");
    const orderButton = document.getElementById("order-button");
    const output = document.getElementById("output");

    // Populate coffee selection
    for (const key in coffeeTypes) {
        const option = document.createElement("option");
        option.value = key;
        option.textContent = coffeeTypes[key].name;
        coffeeSelect.appendChild(option);
    }

    // Handle order button click
    orderButton.addEventListener("click", () => {
        const selectedCoffee = coffeeSelect.value;
        if (selectedCoffee) {
            const coffee = coffeeTypes[selectedCoffee];
            output.textContent = `You ordered a ${coffee.name}. Total: $${coffee.price.toFixed(2)}`;
        } else {
            output.textContent = "Please select a coffee type.";
        }
    });
});

// コーヒー・カフェラテの色
const COFFEE_COLOR = '#2a1a17';
const LATTE_COLOR = '#f7e3c2';
const DEFAULT_COLOR = '#453a39';

const spoutBgPanel = document.getElementById('spout-bg-panel');

function setSpoutPanelColor(type) {
  if (!spoutBgPanel) return;
  if (type === 'coffee') {
    spoutBgPanel.style.background = COFFEE_COLOR;
  } else if (type === 'latte') {
    spoutBgPanel.style.background = LATTE_COLOR;
  } else {
    spoutBgPanel.style.background = DEFAULT_COLOR;
  }
}

// ボタンにイベントを付与
const coffeeBtns = document.querySelectorAll('.coffee-btn.coffee, .coffee-btn.coffee-ice');
const latteBtns = document.querySelectorAll('.coffee-btn.latte, .coffee-btn.latte-ice');

coffeeBtns.forEach(btn => {
  btn.addEventListener('click', () => setSpoutPanelColor('coffee'));
});
latteBtns.forEach(btn => {
  btn.addEventListener('click', () => setSpoutPanelColor('latte'));
});

// どこかクリックでリセット（任意）
document.body.addEventListener('click', (e) => {
  if (!e.target.closest('.coffee-btn')) {
    setSpoutPanelColor();
  }
});

document.addEventListener('DOMContentLoaded', () => {
  const step1 = document.getElementById('step1');
  const step2 = document.getElementById('step2');
  const step3 = document.getElementById('step3');
  const spoutBgPanel = document.getElementById('spout-bg-panel');
  let selectedType = null;
  let selectedTemp = null;
  let selectedSize = null;

  function updateSpoutPanelColor() {
    if (!spoutBgPanel) return;
    spoutBgPanel.classList.remove('coffee', 'latte');
    if (selectedType === 'coffee') {
      spoutBgPanel.classList.add('coffee');
    } else if (selectedType === 'latte') {
      spoutBgPanel.classList.add('latte');
    }
  }

  // コーヒー/カフェラテ（必須）
  step1.querySelectorAll('.select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      step1.querySelectorAll('.select-btn').forEach(b => b.classList.remove('selected'));
      btn.classList.add('selected');
      selectedType = btn.dataset.type;
      updateSpoutPanelColor();
    });
  });

  // ホット/アイス（どちらか一方のみ選択可）
  step2.querySelectorAll('.select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      step2.querySelectorAll('.select-btn').forEach(b => b.classList.remove('selected'));
      if (!btn.classList.contains('selected')) {
        btn.classList.add('selected');
        selectedTemp = btn.dataset.temp;
      } else {
        selectedTemp = null;
      }
    });
  });

  // サイズ（どちらか一方のみ選択可）
  step3.querySelectorAll('.select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      step3.querySelectorAll('.select-btn').forEach(b => b.classList.remove('selected'));
      if (!btn.classList.contains('selected')) {
        btn.classList.add('selected');
        selectedSize = btn.dataset.size;
      } else {
        selectedSize = null;
      }
    });
  });

  updateSpoutPanelColor();
});